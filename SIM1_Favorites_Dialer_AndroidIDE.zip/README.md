# SIM 1 Favorites Dialer

Target: OnePlus Nord CE 2 / OxygenOS 13 / Android 12-13 class devices.

What this prototype does:
- Lets you choose the PhoneAccount that represents SIM 1.
- Lets you become the Android default Phone app.
- If protection is ON, incoming calls routed through the selected SIM 1 account are checked.
- Starred/Favorite contacts are allowed.
- Non-Favorite SIM 1 calls are rejected before they can ring.
- SIM 2 is not acted on.

Important limitation:
Android's public InCallService API exposes the call's PhoneAccount, so per-SIM routing can be identified. However, it does not expose a per-call ringtone-silence operation. Therefore this prototype REJECTS non-Favorite SIM 1 calls rather than merely muting them.

Build on AndroidIDE:
1. Install AndroidIDE from its official/GitHub/F-Droid sources.
2. Extract this project to a writable folder.
3. Open the project in AndroidIDE.
4. Allow it to install the required JDK/SDK/build tools.
5. Sync the Gradle project.
6. Run/assemble the debug APK.
7. Install it.
8. Open it, grant Contacts/Phone permissions.
9. Tap "Make this the default Phone app".
10. Select the PhoneAccount corresponding to SIM 1 and tap "Save SIM 1".
11. Turn on "Protect SIM 1 (Favorites only)".
12. Test first with a non-important number.

This is an experimental prototype. Emergency calls are handled by Android's preloaded emergency path.
