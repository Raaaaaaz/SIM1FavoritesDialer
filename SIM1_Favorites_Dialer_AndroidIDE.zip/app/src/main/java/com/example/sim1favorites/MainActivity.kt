package com.example.sim1favorites

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telecom.TelecomManager
import android.view.Gravity
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var simSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestPermissionsIfNeeded()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
        }

        val title = TextView(this).apply {
            text = "SIM 1 Favorites Dialer"
            textSize = 24f
            setTextColor(Color.BLACK)
        }
        root.addView(title)

        val info = TextView(this).apply {
            text = "\nGoal: SIM 1 allows only starred/Favorite contacts. SIM 2 remains unrestricted.\n"
            textSize = 16f
        }
        root.addView(info)

        status = TextView(this).apply {
            textSize = 15f
        }
        root.addView(status)

        val roleButton = Button(this).apply {
            text = "Make this the default Phone app"
            setOnClickListener { requestDialerRole() }
        }
        root.addView(roleButton)

        val simLabel = TextView(this).apply {
            text = "\nSelect which PhoneAccount is SIM 1:"
            textSize = 16f
        }
        root.addView(simLabel)

        simSpinner = Spinner(this)
        root.addView(simSpinner)

        val saveSim = Button(this).apply {
            text = "Save SIM 1"
            setOnClickListener { saveSelectedAccount() }
        }
        root.addView(saveSim)

        val protect = Switch(this).apply {
            text = "Protect SIM 1 (Favorites only)"
            isChecked = Settings.protectSim1(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                Settings.setProtectSim1(this@MainActivity, checked)
                updateStatus()
            }
        }
        root.addView(protect)

        val note = TextView(this).apply {
            text = "\nImportant: Android's public InCallService API can reliably reject a SIM-1 call before it rings, but it does not provide a per-call ringtone-silence method. This first version therefore REJECTS non-Favorite SIM-1 calls rather than merely muting them. SIM 2 is left alone."
            textSize = 14f
        }
        root.addView(note)

        setContentView(root)
        loadPhoneAccounts()
        updateStatus()
    }

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.READ_CONTACTS)
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.READ_PHONE_STATE)
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 100)
    }

    private fun requestDialerRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
            startActivityForResult(
                rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 200
            )
        } else {
            Toast.makeText(this, "Dialer role is unavailable on this device.", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadPhoneAccounts() {
        val telecom = getSystemService(TELECOM_SERVICE) as TelecomManager
        val accounts = telecom.callCapablePhoneAccounts
        if (accounts.isEmpty()) {
            simSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                listOf("No SIM accounts found"))
            return
        }

        val labels = accounts.mapIndexed { index, h ->
            val p = telecom.getPhoneAccount(h)
            "${index + 1}. ${p?.label ?: h.id}"
        }

        simSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        simSpinner.tag = accounts
    }

    private fun saveSelectedAccount() {
        @Suppress("UNCHECKED_CAST")
        val accounts = simSpinner.tag as? List<android.telecom.PhoneAccountHandle> ?: return
        val pos = simSpinner.selectedItemPosition
        if (pos !in accounts.indices) return

        getSharedPreferences("settings", MODE_PRIVATE).edit()
            .putString("sim1_account_id", accounts[pos].id)
            .apply()

        Toast.makeText(this, "Saved as SIM 1", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun updateStatus() {
        val role = getSystemService(RoleManager::class.java)
        val dialer = role?.isRoleHeld(RoleManager.ROLE_DIALER) == true
        val sim = getSharedPreferences("settings", MODE_PRIVATE)
            .getString("sim1_account_id", null)

        status.text = "Default Phone app: ${if (dialer) "YES" else "NO"}\n" +
                "SIM 1 selected: ${if (sim != null) "YES" else "NO"}\n" +
                "Protection: ${if (Settings.protectSim1(this)) "ON" else "OFF"}"
    }
}