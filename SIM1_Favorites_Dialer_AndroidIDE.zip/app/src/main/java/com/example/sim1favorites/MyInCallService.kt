package com.example.sim1favorites

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.telecom.Call
import android.telecom.InCallService
import android.telecom.PhoneAccount
import android.telecom.PhoneAccountHandle
import android.util.Log

class MyInCallService : InCallService() {

    companion object {
        private const val TAG = "Sim1FavDialer"
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        if (call.details.callDirection != Call.Details.DIRECTION_INCOMING) return

        val details = call.details
        val account = details.accountHandle
        val number = details.handle?.schemeSpecificPart

        Log.d(TAG, "Incoming call. account=$account number=$number")

        if (!Settings.protectSim1(this)) return

        if (isLikelySim1(account) && !isStarred(number)) {
            // Android's public InCallService API does not expose a per-call
            // "silence ringtone" operation. Rejecting here is the reliable
            // per-SIM action available to a default dialer.
            // The call is not allowed to ring.
            Log.d(TAG, "SIM1 non-favorite -> reject")
            call.reject(false, null)
        }
    }

    private fun isStarred(number: String?): Boolean {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) return false
        return ContactUtils.isStarredContact(this, number)
    }

    private fun isLikelySim1(handle: PhoneAccountHandle?): Boolean {
        if (handle == null) return false
        val telecom = getSystemService(TELECOM_SERVICE) as android.telecom.TelecomManager
        val pa = telecom.getPhoneAccount(handle) ?: return false

        // We cannot safely assume an account label is SIM1 on every carrier/OxygenOS build.
        // Prefer explicit user selection when available; for this first version,
        // the UI lets the user record the SIM1 PhoneAccount ID.
        val id = handle.id ?: return false
        val saved = getSharedPreferences("settings", MODE_PRIVATE)
            .getString("sim1_account_id", null)
        return saved != null && saved == id
    }
}