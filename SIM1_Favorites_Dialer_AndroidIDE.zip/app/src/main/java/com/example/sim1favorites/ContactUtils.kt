package com.example.sim1favorites

import android.content.Context
import android.provider.ContactsContract
import android.telephony.PhoneNumberUtils

object ContactUtils {

    /** Returns true only if the number belongs to a starred/favorite contact. */
    fun isStarredContact(context: Context, number: String?): Boolean {
        if (number.isNullOrBlank()) return false

        val uri = ContactsContract.PhoneLookup.CONTENT_FILTER_URI
            .buildUpon().appendPath(number).build()

        val projection = arrayOf(
            ContactsContract.PhoneLookup.CONTACT_ID,
            ContactsContract.PhoneLookup.STARRED
        )

        context.contentResolver.query(uri, projection, null, null, null)?.use { c ->
            val starredIdx = c.getColumnIndex(ContactsContract.PhoneLookup.STARRED)
            while (c.moveToNext()) {
                if (starredIdx >= 0 && c.getInt(starredIdx) == 1) return true
            }
        }

        // Fallback: normalize and scan phone numbers if PhoneLookup didn't match.
        val wanted = PhoneNumberUtils.normalizeNumber(number)
        if (wanted.isEmpty()) return false

        val p = arrayOf(
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.STARRED
        )
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            p, null, null, null
        )?.use { c ->
            val numIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val starIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.STARRED)
            while (c.moveToNext()) {
                if (starIdx >= 0 && c.getInt(starIdx) == 1) {
                    val n = PhoneNumberUtils.normalizeNumber(c.getString(numIdx) ?: "")
                    if (n == wanted || (n.length >= 10 && wanted.endsWith(n.takeLast(10))) ||
                        (wanted.length >= 10 && n.endsWith(wanted.takeLast(10)))) {
                        return true
                    }
                }
            }
        }
        return false
    }
}