package com.example.sim1favorites

import android.content.Context

object Settings {
    private const val PREFS = "settings"
    private const val PROTECT_SIM1 = "protect_sim1"

    fun protectSim1(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(PROTECT_SIM1, false)

    fun setProtectSim1(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(PROTECT_SIM1, value).apply()
    }
}