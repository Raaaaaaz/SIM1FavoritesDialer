plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.sim1favorites"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.sim1favorites"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
}

kotlin {
    jvmToolchain(17)
}